# Início - Guia de Implementação InspiraRIRA v0.1.0

* [**Table of Contents**](toc.md)
* **Início**

## Início

| | |
| :--- | :--- |
| *Official URL*:http://fhir.hsl.org.br/ig/inspirarira/ImplementationGuide/br.org.hsl.inspirarira | *Version*:0.1.0 |
| Draft as of 2026-10-01 | *Computable Name*:InspiraRIRA |

# Guia de Implementação InspiraRIRA

Guia FHIR **R4 (4.0.1)** que refatora o **RIRA** (Regulação Assistencial da RNDS) para o workflow nativo do FHIR.

> Status `draft`. Os artefatos são proposta técnica para deliberação e não declaram conformidade nacional. O desenho segue o **Guia de Implementação FHIR para Regulação e Processamento Financeiro no Brasil** (Working Draft 0.1, GT Financeiro do HL7 Brasil) e o comparativo RIRA x BR-Core x R4.

## Por que refatorar

O RIRA embrulha todo o ciclo da regulação numa Composition (`BRRegulacaoAssistencial`) com sete slices de `Composition.event`. Como `Composition.event` é 1..1 por documento, cada documento guarda um único estado: é um retrato, não um histórico. Além disso, o atendimento aparece duas vezes, no Encounter do RAC e no evento `attended`, sem ligação entre os dois.

O FHIR já tem esse ciclo nativo:

| | | |
| :--- | :--- | :--- |
| Pedido clínico | ServiceRequest | [RequisicaoRegulacao](StructureDefinition-requisicao-regulacao.md) |
| Trabalho e decisão regulatória | Task | [TarefaRegulacao](StructureDefinition-tarefa-regulacao.md) |
| Agendamento | Appointment | [AgendamentoRegulacao](StructureDefinition-agendamento-regulacao.md) |
| Atendimento ambulatorial | Encounter | br-core-encounter (sem perfil novo) |
| Autorização APAC/AIH | Claim / ClaimResponse | [AutorizacaoPreviaSUS](StructureDefinition-autorizacao-previa-sus.md),[RespostaAutorizacaoSUS](StructureDefinition-resposta-autorizacao-sus.md) |
| Produção BPA-I, RAAS, APAC, AIH | Claim | [ProducaoSUS](StructureDefinition-producao-sus.md) |
| Composição e prazo da OCI | PlanDefinition | [ProtocoloOCI](StructureDefinition-protocolo-oci.md) |
| Regra de reembolso da OCI | ChargeItemDefinition | [RegraReembolsoOCI](StructureDefinition-regra-reembolso-oci.md) |
| Leito | Location | [LeitoRegulado](StructureDefinition-leito-regulado.md) |
| Reserva e internação | Encounter | [InternacaoRegulada](StructureDefinition-internacao-regulada.md) |
| Transporte sanitário | ServiceRequest | [TransporteSanitario](StructureDefinition-transporte-sanitario.md) |
| Censo de leitos | MeasureReport | [CensoLeitos](StructureDefinition-censo-leitos.md) |

## Princípios

* **Clínica antes do faturamento.** O ServiceRequest expressa a necessidade. Claim nunca é a única representação do cuidado.
* **A decisão regulatória está na Task**, inclusive a autorização. Claim e ClaimResponse são a camada administrativo-financeira.
* **Status nativos.** ServiceRequest.status guarda só a vigência clínica. Fila, pendência, autorização e agendamento vão para `Task.businessStatus`.
* **Negativa com motivo computável.** Toda negativa informa a dimensão que falhou e o motivo.
* **BR-Core como base.** ServiceRequest, Appointment, Encounter, Patient e Organization derivam do BR-Core 1.3.0 ou o referenciam.
* **Terminologias pelas URLs do guia de terminologia** (`terminologia.saude.gov.br/fhir`).

## Páginas

* [Fluxo regulatório](fluxo.md): estados de negócio e transições.
* [Autorização na Task](autorizacao.md): autorização regulatória, APAC/AIH, produção e reembolso de OCI.
* [Regulação de leitos](leitos.md): reserva, internação, transferência interna e externa, vaga zero, alta e censo.
* [Mapeamento RIRA](mapeamento-rira.md): de cada slice legado para o modelo nativo.
* [Débitos técnicos](debitos-tecnicos.md): achados do comparativo e como este guia os trata.
* [Recomendações à RNDS](recomendacoes-rnds.md).
* [Transição e convivência](transicao.md).
* [Artefatos](artifacts.md).

### Dependências



### Análise entre versões do FHIR

This is an R4 IG. None of the features it uses are changed in R4B, so it can be used as is with R4B systems. Packages for both [R4 (br.org.hsl.inspirarira.r4)](package.r4.tgz) and [R4B (br.org.hsl.inspirarira.r4b)](package.r4b.tgz) are available.

### Propriedade intelectual

Este publication inclui o IP abrangido pelas seguintes declarações.

* This material derives from the HL7 Terminology (THO). THO is copyright ©1989+ Health Level Seven International and is made available under the CC0 designation. For more licensing information see: [https://terminology.hl7.org/license.html](https://terminology.hl7.org/license.html)

* [Claim Type Codes](http://terminology.hl7.org/7.1.0/CodeSystem-claim-type.html): [Claim/bpai-consulta-nefrologia](Claim-bpai-consulta-nefrologia.md), [Claim/claim-aih-icc](Claim-claim-aih-icc.md)... Show 5 more, [Claim/claim-apac-hemodialise](Claim-claim-apac-hemodialise.md), [Claim/producao-apac-hemodialise](Claim-producao-apac-hemodialise.md), [Claim/producao-oci-mama](Claim-producao-oci-mama.md), [ClaimResponse/claimresponse-aih-icc](ClaimResponse-claimresponse-aih-icc.md) and [ClaimResponse/claimresponse-apac-hemodialise](ClaimResponse-claimresponse-apac-hemodialise.md)
* [Condition Clinical Status Codes](http://terminology.hl7.org/7.1.0/CodeSystem-condition-clinical.html): [Condition/condicao-drc](Condition-condicao-drc.md) and [Condition/condicao-icc](Condition-condicao-icc.md)
* [ConditionVerificationStatus](http://terminology.hl7.org/7.1.0/CodeSystem-condition-ver-status.html): [Condition/condicao-drc](Condition-condicao-drc.md) and [Condition/condicao-icc](Condition-condicao-icc.md)
* [Location type](http://terminology.hl7.org/7.1.0/CodeSystem-location-physical-type.html): [Clínica Médica, leito 01](Location-leito-clin-01.md), [Enfermaria, leito 07](Location-leito-origem-01.md), [LeitoRegulado](StructureDefinition-leito-regulado.md), [UTI Adulto, leito 01](Location-leito-uti-01.md) and [UTI Adulto, leito 02](Location-leito-uti-02.md)
* [Measure Scoring](http://terminology.hl7.org/7.1.0/CodeSystem-measure-scoring.html): [CensoLeitos](Measure-censo-leitos.md)
* [MeasureType](http://terminology.hl7.org/7.1.0/CodeSystem-measure-type.html): [CensoLeitos](Measure-censo-leitos.md)
* [PlanDefinitionType](http://terminology.hl7.org/7.1.0/CodeSystem-plan-definition-type.html): [ProtocoloAcessoNefrologia](PlanDefinition-protocolo-acesso-nefrologia.md), [ProtocoloOCI](StructureDefinition-protocolo-oci.md), [ProtocoloOCIIC](PlanDefinition-protocolo-oci-ic.md) and [ProtocoloOCIMama](PlanDefinition-protocolo-oci-mama.md)
* [Process Priority Codes](http://terminology.hl7.org/7.1.0/CodeSystem-processpriority.html): [Claim/bpai-consulta-nefrologia](Claim-bpai-consulta-nefrologia.md), [Claim/claim-aih-icc](Claim-claim-aih-icc.md), [Claim/claim-apac-hemodialise](Claim-claim-apac-hemodialise.md), [Claim/producao-apac-hemodialise](Claim-producao-apac-hemodialise.md) and [Claim/producao-oci-mama](Claim-producao-oci-mama.md)
* [UsageContextType](http://terminology.hl7.org/7.1.0/CodeSystem-usage-context-type.html): [ProtocoloOCIIC](PlanDefinition-protocolo-oci-ic.md) and [ProtocoloOCIMama](PlanDefinition-protocolo-oci-mama.md)
* [bedStatus](http://terminology.hl7.org/7.1.0/CodeSystem-v2-0116.html): [Clínica Médica, leito 01](Location-leito-clin-01.md), [Enfermaria, leito 07](Location-leito-origem-01.md), [LeitoRegulado](StructureDefinition-leito-regulado.md), [UTI Adulto, leito 01](Location-leito-uti-01.md) and [UTI Adulto, leito 02](Location-leito-uti-02.md)
* [identifierType](http://terminology.hl7.org/7.1.0/CodeSystem-v2-0203.html): [Central de Regulação Ambulatorial Exemplo](Organization-org-central-regulacao.md), [Hospital Exemplo](Organization-org-executante.md)... Show 6 more, [Hospital Regional Exemplo](Organization-org-hospital-destino.md), [Patient/paciente-joao](Patient-paciente-joao.md), [Patient/paciente-maria](Patient-paciente-maria.md), [Secretaria Estadual de Saúde Exemplo](Organization-org-gestor-ses.md), [UBS Jardim Exemplo](Organization-org-ubs-solicitante.md) and [UPA 24h Exemplo](Organization-org-upa.md)
* [ActCode](http://terminology.hl7.org/7.1.0/CodeSystem-v3-ActCode.html): [Encounter/enc-alta-uti](Encounter-enc-alta-uti.md), [Encounter/enc-consulta-nefrologia](Encounter-enc-consulta-nefrologia.md)... Show 5 more, [Encounter/enc-destino-uti](Encounter-enc-destino-uti.md), [Encounter/enc-hemodialise](Encounter-enc-hemodialise.md), [Encounter/enc-oci-mama](Encounter-enc-oci-mama.md), [Encounter/enc-origem-enfermaria](Encounter-enc-origem-enfermaria.md) and [Encounter/enc-reserva-clinico](Encounter-enc-reserva-clinico.md)


